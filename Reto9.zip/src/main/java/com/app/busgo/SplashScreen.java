package com.app.busgo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        ImageView mLogoImageView = (ImageView) findViewById(R.id.iv_logo_splash);
        Animation fade = AnimationUtils.loadAnimation(this, R.anim.animation);
        assert mLogoImageView != null;
        mLogoImageView.setAnimation(fade);
        final Intent mainActivityIntent = new Intent(this,IntroductionActivity.class);
        Thread timer = new Thread(){
            @Override
            public void run() {
                super.run();
                try{
                    sleep(2000);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finally{
                    startActivity(mainActivityIntent);
                    finish();
                }
            }
        };
        timer.start();
    }
}
