package com.app.busgo.utils;

import android.content.Context;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by larra on 1/10/2017.
 * Utility functions to handle Google Places API JSON data.
 */

public class BusStopsJSONUtils {

    /**
     * Parses the Json obtained From Google places API into a List of locations ids, corresponding
     * to bus stations
     * @param context context from where it's called
     * @param placesListJsonStr plane string containing json from Google Places API
     * @return List of bus stations ids
     * @throws JSONException if JSON data cannot be properly parsed
     */
    public static String[] getBusLocationsIDSFromJSON(Context context, String placesListJsonStr) throws JSONException {
        final String GPA_STATUS = "status";
        final String GPA_RESULTS = "results";

        final String GPA_STATUS_OK = "OK";
        final String GPA_STATUS_ZERO_RESULTS = "REQUEST_DENIED";
        final String GPA_ID = "place_id";

        String[] stationLocations;

        JSONObject placesJson = new JSONObject(placesListJsonStr);

        if(placesJson.has(GPA_STATUS)){
            String status = placesJson.getString(GPA_STATUS);
            if(status.equals(GPA_STATUS_ZERO_RESULTS)){
                return new String[0];
            }
            else if(!status.equals(GPA_STATUS_OK) ) {
                return null;
            }
        }

        JSONArray locationsArray = placesJson.getJSONArray(GPA_RESULTS);
        stationLocations = new String[locationsArray.length()];

        for(int i = 0; i <locationsArray.length(); i++){
            String location_id;
            JSONObject locationInfo = locationsArray.getJSONObject(i);
            location_id = locationInfo.getString(GPA_ID);
            stationLocations[i] = location_id;
        }
        return stationLocations;
    }
}
