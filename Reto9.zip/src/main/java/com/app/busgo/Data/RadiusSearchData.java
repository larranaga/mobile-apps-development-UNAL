package com.app.busgo.Data;

import com.google.android.gms.maps.model.LatLng;

/**
 * Created by larra on 1/10/2017.
 */

public class RadiusSearchData {
    private LatLng location;
    private double radius;

    public RadiusSearchData(LatLng _location, double _radius){
        location = _location;
        radius = _radius;
    }

    public void setLocation(LatLng location) {
        this.location = location;
    }

    public void setRadius(double radius){
        this.radius = radius;
    }

    public LatLng getLocation() {
        return location;
    }

    public double getRadius() {
        return radius;
    }
}
