package com.app.busgo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BusStatusActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_status);
        setTitle(R.string.title_activity_bus);
    }
}
