package com.app.busgo;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import com.app.busgo.dummy.DummyContent;
import com.app.busgo.dummy.DummyContent2;

public class SelectionActivity extends AppCompatActivity implements RouteFragment.OnListFragmentInteractionListener, StopFragment.OnListFragmentInteractionListener {

    //TODO reemplazar éste botón con la selección de una parada/ruta(s)
    Button contin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stops);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent intent = getIntent();
        setTitle(getString(R.string.route_selection_title));

        StopFragment stopFragment = new StopFragment();
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction();
        transaction.replace(R.id.contentFragment, stopFragment);
        transaction.commit();


        contin = (Button) findViewById(R.id.bt_continue);
        contin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                //TODO: Añadir fragmento selección de paradero
//                setTitle(getString(R.string.title_choose_bus));
//                RouteFragment routeFragment = new RouteFragment();
//                FragmentManager fm = getSupportFragmentManager();
//                FragmentTransaction transaction = fm.beginTransaction();
//                transaction.replace(R.id.contentFragment, routeFragment);
//                transaction.commit();
//
//                contin.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
                        Intent intentBusesStatusActivity = new Intent(getApplicationContext(), BusesStatusActivity.class);
                        startActivity(intentBusesStatusActivity);
//                    }
//                });
            }
        });
    }

    @Override
    public void onListFragmentInteraction(DummyContent.DummyItem item) {

    }

    @Override
    public void onListFragmentInteraction(DummyContent2.DummyItem2 item) {

    }
}
