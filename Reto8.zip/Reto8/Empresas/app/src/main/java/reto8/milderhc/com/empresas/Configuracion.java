package reto8.milderhc.com.empresas;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;

public class Configuracion extends PreferenceActivity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        addPreferencesFromResource(R.xml.configuracion);

        final SharedPreferences prefs =
                PreferenceManager.getDefaultSharedPreferences(getBaseContext());

        final EditTextPreference nombrePref = (EditTextPreference)
                findPreference("Nombre");
        String nombre = prefs.getString(EmpresaDBAdapter.C_COLUMNA_NOMBRE, "");

        nombrePref.setSummary((CharSequence) nombre);

        nombrePref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                nombrePref.setSummary((CharSequence) newValue);

                // Since we are handling the pref, we must save it
                SharedPreferences.Editor ed = prefs.edit();
                ed.putString(EmpresaDBAdapter.C_COLUMNA_NOMBRE, newValue.toString());
                ed.commit();
                return true;
            }
        });



        final EditTextPreference clasificacionPref = (EditTextPreference)
                findPreference("Clasificacion");
        String clasificacion = prefs.getString(EmpresaDBAdapter.C_COLUMNA_CLASIFICACION, "");

        clasificacionPref.setSummary((CharSequence) clasificacion);

        clasificacionPref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                clasificacionPref.setSummary((CharSequence) newValue);

                // Since we are handling the pref, we must save it
                SharedPreferences.Editor ed = prefs.edit();
                ed.putString(EmpresaDBAdapter.C_COLUMNA_CLASIFICACION, newValue.toString());
                ed.commit();
                return true;
            }
        });
    }
}
