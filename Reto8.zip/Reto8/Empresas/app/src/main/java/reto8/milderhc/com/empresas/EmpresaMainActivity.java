package reto8.milderhc.com.empresas;

import android.app.ActionBar;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.Toolbar;

public class EmpresaMainActivity extends ListActivity {

    public static final String C_MODO = "modo";
    public static final int C_VISUALIZAR = 551;
    public static final int C_CREAR = 552;
    public static final int C_EDITAR = 553;
    public static final int C_ELIMINAR = 554;
    public static final int C_CONFIGURAR = 555;

    private EmpresaDBAdapter dbAdapter;
    private Cursor cursor;
    private EmpresaCursorAdapter hipotecaAdapter;
    private ListView lista;

    public String filtro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empresa_main);

        lista = (ListView) findViewById(android.R.id.list);

        dbAdapter = new EmpresaDBAdapter(this);
        dbAdapter.abrir();

        consultar();

        registerForContextMenu(this.getListView());
    }


    private void consultar() {
        cursor = dbAdapter.getCursor(filtro);
        startManagingCursor(cursor);
        hipotecaAdapter = new EmpresaCursorAdapter(this, cursor);
        lista.setAdapter(hipotecaAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onMenuItemSelected(int featureId, MenuItem item) {
        Intent i;

        switch (item.getItemId()) {
            case R.id.menu_crear:
                i = new Intent(this, EmpresaFormularioActivity.class);
                i.putExtra(C_MODO, C_CREAR);
                startActivityForResult(i, C_CREAR);
                return true;
            case R.id.menu_preferencias:
                i = new Intent(this, Configuracion.class);
                startActivityForResult(i, C_CONFIGURAR);
                return true;
        }

        return super.onMenuItemSelected(featureId, item);
    }

    private void visualizar(long id) {
        Intent i = new Intent(this, EmpresaFormularioActivity.class);
        i.putExtra(C_MODO, C_VISUALIZAR);
        i.putExtra(dbAdapter.C_COLUMNA_ID, id);

        startActivityForResult(i, C_VISUALIZAR);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        visualizar(id);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {
            case C_CREAR:
                if (resultCode == RESULT_OK)
                    consultar();

            case C_VISUALIZAR:
                if (resultCode == RESULT_OK)
                    consultar();

            case C_CONFIGURAR:
                // en la PreferenceActivity no hemos definido ningún resultado por lo que recargamos
                // siempre las preferencias
                getPreferencias();
                consultar();

            default:
                super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void borrar(final long id) {
        //
        // Borramos el registro y refrescamos la lista
        //
        AlertDialog.Builder dialogEliminar = new AlertDialog.Builder(this);

        dialogEliminar.setIcon(android.R.drawable.ic_dialog_alert);
        dialogEliminar.setTitle(getResources().getString(R.string.empresa_eliminar_titulo));
        dialogEliminar.setMessage(getResources().getString(R.string.empresa_eliminar_mensaje));
        dialogEliminar.setCancelable(false);

        dialogEliminar.setPositiveButton(getResources().getString(android.R.string.ok), new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int boton) {
                dbAdapter.delete(id);
                Toast.makeText(EmpresaMainActivity.this, R.string.empresa_eliminar_confirmacion, Toast.LENGTH_SHORT).show();
                consultar();
            }
        });

        dialogEliminar.setNegativeButton(android.R.string.no, null);

        dialogEliminar.show();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        menu.setHeaderTitle(cursor.getString(cursor.getColumnIndex(dbAdapter.C_COLUMNA_NOMBRE)));
        menu.add(Menu.NONE, C_VISUALIZAR, Menu.NONE, R.string.menu_visualizar);
        menu.add(Menu.NONE, C_EDITAR, Menu.NONE, R.string.menu_editar);
        menu.add(Menu.NONE, C_ELIMINAR, Menu.NONE, R.string.menu_eliminar);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        Intent i;

        switch (item.getItemId()) {
            case C_ELIMINAR:
                borrar(info.id);
                return true;

            case C_VISUALIZAR:
                visualizar(info.id);
                return true;

            case C_EDITAR:
                i = new Intent(this, EmpresaFormularioActivity.class);
                i.putExtra(C_MODO, C_EDITAR);
                i.putExtra(dbAdapter.C_COLUMNA_ID, info.id);

                startActivityForResult(i, C_EDITAR);
                return true;
        }
        return super.onContextItemSelected(item);
    }

    private void getPreferencias() {
        //
        // Recuperamos las preferencias
        //
        SharedPreferences preferencias = PreferenceManager.getDefaultSharedPreferences(this);
        String nombre = preferencias.getString(dbAdapter.C_COLUMNA_NOMBRE, "");
        String clasificacion = preferencias.getString(dbAdapter.C_COLUMNA_CLASIFICACION, "");

        if ( nombre.equals("") && clasificacion.equals("") ) { filtro = null; return; }

        if ( !nombre.equals("") && !clasificacion.equals("") )
            this.filtro = dbAdapter.C_COLUMNA_NOMBRE + " LIKE '%" + nombre + "%' AND " +
                          dbAdapter.C_COLUMNA_CLASIFICACION + " LIKE '%" + clasificacion + "%'";
        else if ( !nombre.equals("") )
            this.filtro = dbAdapter.C_COLUMNA_NOMBRE + " LIKE '%" + nombre + "%'";
        else
            this.filtro = dbAdapter.C_COLUMNA_CLASIFICACION + " LIKE '%" + clasificacion + "%'";

        Log.d("jaja", filtro);
    }

}
